/**
 * @module rollup.esm
 */

import rollup from './rollup.base';

export default rollup(true);
