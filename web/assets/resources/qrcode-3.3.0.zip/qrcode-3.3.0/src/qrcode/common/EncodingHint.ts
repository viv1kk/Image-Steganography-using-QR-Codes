/**
 * @module EncodingHint
 * @author nuintun
 */

export const enum EncodingHint {
  SJIS = 20,
  UTF8 = 26
}
